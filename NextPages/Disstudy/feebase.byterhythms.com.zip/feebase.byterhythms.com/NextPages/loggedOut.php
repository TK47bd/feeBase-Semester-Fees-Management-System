<!-- 
    Document   : feeBase
    Created on : Jan 4, 2020, 3:30:23 AM
    Author     : TK47bd @byteRhythms tech.
-->

<?php
session_start();
?>

       
<?php
             
                 session_destroy();
             ?> <script> alert("Succesfully Logged Out!!"); </script> <?php
                 header("location:../index.html"); 
                 
?>

